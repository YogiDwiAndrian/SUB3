package com.yogi.moviecatalog.Models

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class TvShow (
    var year: String = "",
    var tittle: String = "",
    var genre: String = "",
    var overview: String = "",
    var rating: Float = 0f,
    var photo: Int = 0,
    var preview: String = "",
    var episodes: Int = 0,
    var seasons: Int = 0
) : Parcelable