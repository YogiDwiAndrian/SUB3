package com.yogi.moviecatalog.UI

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.webkit.WebView
import android.widget.ImageView
import android.widget.RatingBar
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.yogi.moviecatalog.Adapter.MovieColAdapter
import com.yogi.moviecatalog.Data.MovieData
import com.yogi.moviecatalog.Models.Movie
import com.yogi.moviecatalog.R
import kotlinx.android.synthetic.main.activity_detail.*

class DetailMovieActivity : AppCompatActivity() {

    //recyclerview horizontal
    private lateinit var rvMovieCol: RecyclerView
    private var list: ArrayList<Movie> = arrayListOf()

    companion object {
        const val EXTRA_MOVIES = "extra_movies"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)

        val movies = intent.getParcelableExtra(EXTRA_MOVIES) as Movie

        //change poster
        val imgPoster: ImageView = img_detail_movie
        val photo = movies.photo
        Glide.with(imgPoster)
            .load(photo)
            .apply(RequestOptions())
            .into(imgPoster)

        //change tittle
        val tvTittle: TextView = tv_detail_tittle
        val tittle = movies.tittle
        tvTittle.text = tittle

        //change year
        val tvyear: TextView = tv_detail_year
        val year = movies.year.toString()
        tvyear.text = year

        //change ratingBar
        val tvRateBar: RatingBar = ratingBar_detail
        val rateBar = movies.rating
        tvRateBar.rating = rateBar / 2

        //change rateNum
        val tvRateNum: TextView = tv_detail_rate
        val rateNum = movies.rating.toString()
        tvRateNum.text = rateNum

        //change overview
        val tvOverview: TextView = tv_detail_overview
        val overview = movies.overview
        tvOverview.text = overview

        //change genres
        val tvGenres: TextView = tv_detail_genres
        val genres = movies.genre
        tvGenres.text = genres

        //change preview
        val vidPreview: WebView = webview
        val preview = movies.preview
        vidPreview.loadUrl(preview)

        rvMovieCol = rv_movie_col
        rvMovieCol.setHasFixedSize(true)

        list.addAll(MovieData.listDataMovies)
        showRecyclerCardView()
    }

     private fun showRecyclerCardView() {
        rvMovieCol.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        val cardViewColAdapter = MovieColAdapter(list)
        rvMovieCol.adapter = cardViewColAdapter


    }


}