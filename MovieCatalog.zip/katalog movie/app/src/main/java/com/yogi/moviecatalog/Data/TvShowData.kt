package com.yogi.moviecatalog.Data

import com.yogi.moviecatalog.Models.TvShow
import com.yogi.moviecatalog.R

object TvShowData {

    private val tvShowYear = arrayOf(
        "2011–2019",
        "2019– ",
        "2019– ",
        "2019– ",
        "2019– ",
        "2019– ",
        "2019",
        "2019",
        "2019– ",
        "2019– ",
        "2019– ",
        "2019"
    )

    private val tvShowTittle = arrayOf(
        "Game of Thrones",
        "The Witcher",
        "The Mandalorian",
        "His Dark Materials",
        "See",
        "The Morning Show",
        "Daybreak ",
        "Watchmen ",
        "Living with Yourself",
        "Batwoman",
        "The Politician",
        "The I-Land "
    )

    private val tvShowGenre = arrayOf(
        "Action, Adventure, Drama",
        "Action, Adventure, Drama",
        "Action, Adventure, Sci-Fi",
        "Adventure, Drama, Family",
        "Action, Drama, Sci-Fi",
        "Drama",
        "Action, Adventure, Comedy",
        "Action, Drama, Mystery",
        "Comedy, Drama",
        "Action, Adventure, Crime",
        "Comedy, Drama",
        "Adventure, Drama, Mystery"
    )

    private val tvShowOverview = arrayOf(
        "Nine noble families fight for control over the mythical lands of Westeros, while an ancient enemy returns after being dormant for thousands of years.",
        "Geralt of Rivia, a solitary monster hunter, struggles to find his place in a world where people often prove more wicked than beasts.",
        "The travels of a lone bounty hunter in the outer reaches of the galaxy, far from the authority of the New Republic.",
        "young girl is destined to liberate her world from the grip of the Magisterium which represses people's ties to magic and their animal spirits known as daemons.",
        "Far in a dystopian future, the human race has lost the sense of sight, and society has had to find new ways to interact, build, hunt, and to survive. All of that is challenged when a set of twins is born with sight.",
        "An inside look at the lives of the people who help America wake up in the morning, exploring the unique challenges faced by the men and women who carry out this daily televised ritual.",
        "High school outcast Josh is searching for his missing girlfriend in post apocalyptic Glendale. He's joined by a group of misfits Angelica and his former bully Wesley. On the way they'll face many weird things.",
        "Set in an alternate history where masked vigilantes are treated as outlaws, Watchmen embraces the nostalgia of the original groundbreaking graphic novel of the same name, while attempting to break new ground of its own.",
        "An existential comedy about a man struggling in life who undergoes a new treatment to become a better person, only to find that he's been replaced by a new and improved version of himself.",
        "Kate Kane seeks justice for Gotham City as Batwoman.",
        "Payton Hobart, a student from Santa Barbara, has known since age seven that he's going to be President of the United States. But first he'll have to navigate the most treacherous political landscape of all: Saint Sebastian High School.",
        "When ten people wake up on a treacherous island with no memory of who they are and how they got there, they set off on a trek to try to get back home, only to discover the world is not as it seems."
    )

    private val tvShowratingBar = floatArrayOf(
        9.3f,
        8.4f,
        8.8f,
        8.0f,
        7.6f,
        8.4f,
        6.8f,
        8.1f,
        7.3f,
        3.4f,
        7.6f,
        4.4f
    )

    private val tvShowPreview = arrayOf(
        "https://www.imdb.com/videoembed/vi3672620057",
        "https://www.imdb.com/videoembed/vi840285977",
        "https://www.imdb.com/videoembed/vi2033827609",
        "https://www.imdb.com/videoembed/vi3822370585",
        "https://www.imdb.com/videoembed/vi1739046681",
        "https://www.imdb.com/videoembed/vi1162591257",
        "https://www.imdb.com/videoembed/vi1351925529",
        "https://www.imdb.com/videoembed/vi619298585",
        "https://www.imdb.com/videoembed/vi2140454681",
        "https://www.imdb.com/videoembed/vi1195032345",
        "https://www.imdb.com/videoembed/vi3130965785",
        "https://www.imdb.com/videoembed/vi659405849"
    )

    private val tvShowEpisodes = arrayOf(
        73,
        16,
        9,
        16,
        9,
        11,
        10,
        9,
        8,
        23,
        16,
        7
    )

    private val tvShowSeasons = arrayOf(
        8,
        2,
        2,
        2,
        2,
        2,
        1,
        1,
        1,
        2,
        2,
        1

    )

    private val tvShowImages = intArrayOf(
        R.drawable.poster_gameofthrones,
        R.drawable.poster_thewitcher,
        R.drawable.poster_mandalorian,
        R.drawable.poster_hisdarkmaterials,
        R.drawable.poster_see,
        R.drawable.poster_themorningshow,
        R.drawable.poster_daybreak,
        R.drawable.poster_watchmen,
        R.drawable.poster_livingwithyourself,
        R.drawable.poster_batwoman,
        R.drawable.poster_thepolitican,
        R.drawable.poster_theiland
    )

    val listDataTvShow: ArrayList<TvShow>
        get() {
            val list = arrayListOf<TvShow>()
            for (position in tvShowTittle.indices) {
                val tvShow = TvShow()
                tvShow.year = tvShowYear[position]
                tvShow.tittle = tvShowTittle[position]
                tvShow.overview = tvShowOverview[position]
                tvShow.genre = tvShowGenre[position]
                tvShow.rating = tvShowratingBar[position]
                tvShow.preview = tvShowPreview[position]
                tvShow.photo = tvShowImages[position]
                tvShow.episodes = tvShowEpisodes[position]
                tvShow.seasons = tvShowSeasons[position]
                list.add(tvShow)
            }
            return list
        }
}