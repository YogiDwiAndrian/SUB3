package com.yogi.moviecatalog.UI.Fragment


import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.yogi.moviecatalog.Adapter.TvShowRowAdapter
import com.yogi.moviecatalog.Data.TvShowData
import com.yogi.moviecatalog.Models.TvShow

import com.yogi.moviecatalog.R
import kotlinx.android.synthetic.main.fragment_tvshow.*

/**
 * A simple [Fragment] subclass.
 */
class TVShowFragment : Fragment() {

    private lateinit var rvTvShow: RecyclerView
    private var list: ArrayList<TvShow> = arrayListOf()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_tvshow, container, false)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        rvTvShow = rv_tvshow
        rvTvShow.setHasFixedSize(true)

        list.addAll(TvShowData.listDataTvShow)
        showRecyclerCardView()
    }

    private fun showRecyclerCardView() {
        rvTvShow.layoutManager = LinearLayoutManager(activity)
        val tvShowRowAdapter = TvShowRowAdapter(list)
        rvTvShow.adapter = tvShowRowAdapter
    }

}
