package com.yogi.moviecatalog.Adapter

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.yogi.moviecatalog.Models.TvShow
import com.yogi.moviecatalog.R
import com.yogi.moviecatalog.UI.DetailTvShowActivity
import kotlinx.android.synthetic.main.item_col_movie.view.*

class TvShowColAdapter (private val listTvShow: ArrayList<TvShow>) : RecyclerView.Adapter<TvShowColAdapter.TvShowViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TvShowViewHolder {
        val view: View = LayoutInflater.from(parent.context).inflate(R.layout.item_col_movie, parent, false)
        return TvShowViewHolder(view)
    }

    override fun onBindViewHolder(holder: TvShowViewHolder, position: Int) {

        val tvshow = listTvShow[position]
        Glide.with(holder.itemView.context)
            .load(tvshow.photo)
            .apply(RequestOptions())
            .into(holder.imgPhoto)
        holder.tvYear.text = tvshow.year
        holder.tvTittle.text = tvshow.tittle

        //send parcelable data intent
        holder.itemView.setOnClickListener {

            val moveWithObjectIntent = Intent(holder.mContext, DetailTvShowActivity::class.java)

            moveWithObjectIntent.putExtra(DetailTvShowActivity.EXTRA_TVSHOW, tvshow)
            holder.mContext.startActivity(moveWithObjectIntent)
        }

    }

    override fun getItemCount(): Int {
        return listTvShow.size
    }

    inner class TvShowViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val mContext: Context = itemView.context
        var imgPhoto: ImageView = itemView.img_movie_col
        var tvYear: TextView = itemView.tv_year_col
        var tvTittle: TextView = itemView.tv_tittle_col
    }
}