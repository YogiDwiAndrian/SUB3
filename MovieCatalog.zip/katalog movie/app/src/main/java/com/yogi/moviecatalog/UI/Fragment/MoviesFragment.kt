package com.yogi.moviecatalog.UI.Fragment


import android.annotation.SuppressLint
import android.os.Bundle
import android.view.*
import android.widget.SearchView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.yogi.moviecatalog.Adapter.MovieRowAdapter
import com.yogi.moviecatalog.Data.MovieData
import com.yogi.moviecatalog.Models.Movie
import com.yogi.moviecatalog.R
import kotlinx.android.synthetic.main.fragment_movies.*


/**
 * A simple [Fragment] subclass.
 */
class MoviesFragment : Fragment() {

    private lateinit var rvMovie: RecyclerView
    private var list: ArrayList<Movie> = arrayListOf()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_movies, container, false)
    }


    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        rvMovie = rv_movie
        rvMovie.setHasFixedSize(true)

        list.addAll(MovieData.listDataMovies)
        showRecyclerCardView()
    }

    private fun showRecyclerCardView() {
        rvMovie.layoutManager = LinearLayoutManager(activity)
        val cardViewKosAdapter = MovieRowAdapter(list)
        rvMovie.adapter = cardViewKosAdapter
    }

}
