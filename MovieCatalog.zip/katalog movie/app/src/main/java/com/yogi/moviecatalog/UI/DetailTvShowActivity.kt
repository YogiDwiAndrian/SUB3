package com.yogi.moviecatalog.UI

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.webkit.WebView
import android.widget.ImageView
import android.widget.RatingBar
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.yogi.moviecatalog.Adapter.TvShowColAdapter
import com.yogi.moviecatalog.Data.TvShowData
import com.yogi.moviecatalog.Models.TvShow
import com.yogi.moviecatalog.R
import kotlinx.android.synthetic.main.activity_detail_tv_show.*

class DetailTvShowActivity : AppCompatActivity() {

    //recyclerview horizontal
    private lateinit var rvTvShowCol: RecyclerView
    private var list: ArrayList<TvShow> = arrayListOf()

    companion object {
        const val EXTRA_TVSHOW = "extra_tvshow"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail_tv_show)

        val tvshow = intent.getParcelableExtra(EXTRA_TVSHOW) as TvShow

        //change poster
        val imgPoster: ImageView = img_detail_tvshow
        val photo = tvshow.photo
        Glide.with(imgPoster)
            .load(photo)
            .apply(RequestOptions())
            .into(imgPoster)

        //change tittle
        val tvTittle: TextView = tv_detail_tittle_tvshow
        val tittle = tvshow.tittle
        tvTittle.text = tittle

        //change year
        val tvyear: TextView = tv_detail_year_tvshow
        val year = tvshow.year
        tvyear.text = year

        //change ratingBar
        val tvRateBar: RatingBar = ratingBar_detail_tvshow
        val rateBar = tvshow.rating
        tvRateBar.rating = rateBar / 2

        //change rateNum
        val tvRateNum: TextView = tv_detail_rate_tvshow
        val rateNum = tvshow.rating.toString()
        tvRateNum.text = rateNum

        //change overview
        val tvOverview: TextView = tv_detail_overview_tvshow
        val overview = tvshow.overview
        tvOverview.text = overview

        //change genres
        val tvGenres: TextView = tv_detail_genres_tvshow
        val genres = tvshow.genre
        tvGenres.text = genres

        //change episode
        val tvEpisodes: TextView = tv_detail_episode_tvshow
        val episodes = tvshow.episodes
        tvEpisodes.text = episodes.toString()

        //change season
        val tvSeasons: TextView = tv_detail_season_tvshow
        val seasons = tvshow.seasons
        tvSeasons.text = seasons.toString()

        //change preview
        val vidPreview: WebView = webview_tvshow
        val preview = tvshow.preview
        vidPreview.loadUrl(preview)

        rvTvShowCol = rv_tvshow_col
        rvTvShowCol.setHasFixedSize(true)

        list.addAll(TvShowData.listDataTvShow)
        showRecyclerCardView()
    }

    private fun showRecyclerCardView() {
        rvTvShowCol.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        val tvShowColAdapter = TvShowColAdapter(list)
        rvTvShowCol.adapter = tvShowColAdapter


    }
}