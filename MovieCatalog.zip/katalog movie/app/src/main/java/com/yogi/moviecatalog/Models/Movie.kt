package com.yogi.moviecatalog.Models

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class Movie (
    var year: Int = 0,
    var tittle: String = "",
    var genre: String = "",
    var overview: String = "",
    var rating: Float = 0f,
    var photo: Int = 0,
    var preview: String = ""
) : Parcelable